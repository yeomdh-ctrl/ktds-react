import { useState } from "react";
import "./ParticipantList.css";
import ParticipantSearch from "./ParticipantSearch.jsx";
import ParticipantTable from "./ParticipantTable.jsx";
import ParticipantPagination from "./ParticipantPagination.jsx";

const dummyData = Array.from({ length: 50 }, (_, i) => ({
  id: i + 1,
  company: `${String.fromCharCode(65 + (i % 5))} 사`,
  member: "김*당",
  participated: i % 3 !== 1,
  date: i % 3 !== 1 ? "2026-05-11" : "-",
}));

const defaultSearch = {
  participation: "전체",
  company: "",
  member: "",
};

const ParticipantList = () => {
  const [{ search, pageSize, currentPage }, setListState] = useState({
    search: defaultSearch,
    pageSize: 10,
    currentPage: 1,
  });

  const onSearchChangeHandler = (field, value) => {
    setListState((prevData) => ({
      ...prevData,
      search: { ...prevData.search, [field]: value },
      currentPage: 1,
    }));
  };

  const onSearchButtonClickHandler = () => {
    setListState((prevData) => ({ ...prevData, currentPage: 1 }));
  };

  const onResetButtonClickHandler = () => {
    setListState((prevData) => ({
      ...prevData,
      search: defaultSearch,
      currentPage: 1,
    }));
  };

  const onPageSizeChangeHandler = (value) => {
    setListState((prevData) => ({
      ...prevData,
      pageSize: Number(value),
      currentPage: 1,
    }));
  };

  const onPageChangeHandler = (page) => {
    setListState((prevData) => ({ ...prevData, currentPage: page }));
  };

  const filteredData = dummyData.filter((what) => {
    const matchParticipation =
      search.participation === "전체" ||
      (search.participation === "참여" && what.participated) ||
      (search.participation === "미참여" && !what.participated);
    const matchCompany =
      search.company === "" || what.company.includes(search.company);
    const matchMember =
      search.member === "" || what.member.includes(search.member);
    return matchParticipation && matchCompany && matchMember;
  });

  const totalPages = Math.ceil(filteredData.length / pageSize);
  const pagedData = filteredData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  return (
    <div className="participant-page">
      <h2>참여 회원 목록</h2>
      <p >설문명 : 2026년 하반기 교육 수요 조사</p>

      <ParticipantSearch
        search={search}
        onSearchChange={onSearchChangeHandler}
        onSearchButtonClick={onSearchButtonClickHandler}
        onResetButtonClick={onResetButtonClickHandler}
      />

      <ParticipantTable data={pagedData} startIndex={(currentPage - 1) * pageSize} />

      <ParticipantPagination
        currentPage={currentPage}
        totalPages={totalPages}
        pageSize={pageSize}
        onPageChange={onPageChangeHandler}
        onPageSizeChange={onPageSizeChangeHandler}
      />
    </div>
  );
};

export default ParticipantList;
