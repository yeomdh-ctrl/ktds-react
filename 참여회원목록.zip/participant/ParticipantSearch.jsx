const options = ["전체", "참여", "미참여"];

const ParticipantSearch = ({ search, onSearchChange, onSearchButtonClick, onResetButtonClick }) => {
  const { participation, company, member } = search;
 
  return (
    <div className="search-bar">
      <div className="search-field">
        <span className="search-label">참여여부</span>
        <select
          className="search-select"
          value={participation}
          onChange={(e) => onSearchChange("participation", e.target.value)}
        >
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      </div>
 
      <div className="search-field">
        <span className="search-label">참여 회사 명</span>
        <input
          className="search-input"
          type="text"
          placeholder="회사명을 입력하세요"
          value={company}
          onChange={(e) => onSearchChange("company", e.target.value)}
        />
      </div>
 
      <div className="search-field">
        <span className="search-label">회원명</span>
        <input
          className="search-input"
          type="text"
          placeholder="회원명을 입력하세요"
          value={member}
          onChange={(e) => onSearchChange("member", e.target.value)}
        />
      </div>
 
      <div className="search-btns">
        <button className="btn btn-search" onClick={onSearchButtonClick}>검색</button>
        <button className="btn btn-reset" onClick={onResetButtonClick}>초기화</button>
      </div>
    </div>
  );
};
 
export default ParticipantSearch;
