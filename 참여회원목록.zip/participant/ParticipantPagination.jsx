const pageOption = [10, 30, 50, 100];

const ParticipantPagination = ({ currentPage, totalPages, pageSize, onPageChange, onPageSizeChange }) => {
const pages = [];
for (let i = 1; i <= totalPages; i++) {
  pages.push(i);
}

  return (
    <div className="pagination-bar">
      <div className="page-size-select">
        <select
          className="search-select"
          value={pageSize}
          onChange={(e) => onPageSizeChange(e.target.value)}
        >
          {pageOption.map((size) => (
            <option key={size} value={size}>{size}개씩 보기</option>
          ))}
        </select>
      </div>

      <div className="page-btns">
        <button
          className="page-btn"
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
        >
          {"<"}
        </button>

        {pages.map((page) => (
          <button
            key={page}
            className="page-btn"
            onClick={() => onPageChange(page)}
          >
            {page}
          </button>
        ))}

        <button
          className="page-btn"
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
        >
          {">"}
        </button>
      </div>
    </div>
  );
};

export default ParticipantPagination;
