const ParticipantTable = ({ data, startIndex }) => {
  return (
    <table className="participant-table">
      <thead>
        <tr>
          <th>순번</th>
          <th>참여 회사명</th>
          <th>회원명</th>
          <th>설문 참여 여부</th>
          <th>참여일시</th>
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => {
          const isNotParticipated = !row.participated;
          return (
            <tr key={row.id} className={isNotParticipated ? "row-absent" : ""}>
              <td>{startIndex + index + 1}</td>
              <td>{row.company}</td>
              <td>{row.member}</td>
              <td>{isNotParticipated ? "미참여" : "참여"}</td>
              <td>{row.date}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default ParticipantTable;
