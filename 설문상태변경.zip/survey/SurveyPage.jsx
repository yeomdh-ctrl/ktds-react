import { useState } from "react";
import "./SurveyStatusModal.css";
import SurveyHeader from "./SurveyHeader.jsx";
import SurveySection from "./SurveySection.jsx";
import SurveyFooter from "./SurveyFooter.jsx";
import StatusModal from "./StatusModal.jsx";

const STATUS_FLOW = ["작성중", "진행중", "완료"];

const getNextStatus = (current) => {
  const idx = STATUS_FLOW.indexOf(current);
  return idx < STATUS_FLOW.length - 1 ? STATUS_FLOW[idx + 1] : null;
};

const SurveyPage = () => {
  const [{ currentStatus, isModalOpen }, setSurveyState] = useState({
    currentStatus: "작성중",
    isModalOpen: false,
  });

  const nextStatus = getNextStatus(currentStatus);

  const onNextStatusButtonClickHandler = () => {
    setSurveyState((prevData) => ({ ...prevData, isModalOpen: true }));
    console.log("상태 변경 모달 열기:", nextStatus);
  };

  const onConfirmButtonClickHandler = () => {
    setSurveyState((prevData) => ({
      ...prevData,
      currentStatus: nextStatus,
      isModalOpen: false,
    }));
    console.log("상태 변경 완료:", nextStatus);
  };

  const onCancelButtonClickHandler = () => {
    setSurveyState((prevData) => ({ ...prevData, isModalOpen: false }));
    console.log("상태 변경 취소");
  };

  return (
    <div className="page">
      <SurveyHeader surveyName="복지 제도 만족도 조사" currentStatus={currentStatus} />
      <SurveySection />
      <SurveyFooter
        nextStatus={nextStatus}
        onNextStatusButtonClick={onNextStatusButtonClickHandler}
      />
      {isModalOpen && (
        <StatusModal
          currentStatus={currentStatus}
          nextStatus={nextStatus}
          onConfirmButtonClick={onConfirmButtonClickHandler}
          onCancelButtonClick={onCancelButtonClickHandler}
        />
      )}
    </div>
  );
};

export default SurveyPage;
